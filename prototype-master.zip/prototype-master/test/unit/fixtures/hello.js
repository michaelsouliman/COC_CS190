$("content").update("<H2>Hello world!</H2>");
